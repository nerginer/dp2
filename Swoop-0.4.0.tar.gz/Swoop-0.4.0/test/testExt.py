
class TestThing:
    def __init__(self):
        pass
    def hello(self):
        return "Hellow from TestThing base class"

class Library(TestThing):
    def __init__(self):
        pass
    def hello(self):
        return "Hello from Library"
    
    
